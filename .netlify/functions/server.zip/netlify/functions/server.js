var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/server.js
var server_exports = {};
__export(server_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_axios = __toESM(require("axios"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_serverless_http = __toESM(require("serverless-http"), 1);
import_dotenv.default.config();
var app = (0, import_express.default)();
app.use((0, import_cors.default)());
app.use(
  import_express.default.json({
    verify: (req, res, buf) => {
      req.rawBody = buf.toString();
    }
  })
);
var DIDIT_API = "https://verification.didit.me/v2";
var API_KEY = process.env.DIDIT_API_KEY;
var WORKFLOW_ID = process.env.DIDIT_WORKFLOW_ID;
var CALLBACK_URL = process.env.CALLBACK_URL;
var WEBHOOK_SECRET = process.env.DIDIT_WEBHOOK_SECRET;
var kycCache = /* @__PURE__ */ new Map();
var router = import_express.default.Router();
router.post("/start-kyc", async (req, res) => {
  try {
    const { email, name, type } = req.body;
    if (!email || !name) {
      return res.status(400).json({ error: "Email and name are required" });
    }
    const response = await import_axios.default.post(
      `${DIDIT_API}/session/`,
      {
        workflow_id: WORKFLOW_ID,
        vendor_data: email,
        callback: CALLBACK_URL,
        metadata: { name, type }
      },
      {
        headers: {
          "x-api-key": API_KEY,
          "Content-Type": "application/json"
        }
      }
    );
    console.log("\u2705 Didit session created:", response.data);
    res.json(response.data);
  } catch (err) {
    console.error("\u274C DIDIT Error:", err.response?.data || err.message);
    res.status(500).json({ error: "Failed to create KYC session" });
  }
});
router.post("/didit-webhook", (req, res) => {
  try {
    const signature = req.headers["x-signature"];
    if (!signature) return res.status(400).send("Missing signature");
    const computedSignature = import_crypto.default.createHmac("sha256", WEBHOOK_SECRET).update(req.rawBody).digest("hex");
    if (computedSignature !== signature) {
      console.warn("\u26A0\uFE0F Invalid webhook signature!");
      return res.status(401).send("Invalid signature");
    }
    const { session_id, vendor_data, status } = req.body;
    if (vendor_data) {
      kycCache.set(vendor_data, {
        status,
        session_id,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    res.sendStatus(200);
  } catch (err) {
    console.error("Webhook error:", err.message);
    res.status(500).send("Internal error");
  }
});
router.get("/kyc-status/:email", async (req, res) => {
  try {
    const email = req.params.email.toLowerCase();
    const cached = kycCache.get(email);
    if (cached) return res.json(cached);
    const response = await import_axios.default.get(
      `${DIDIT_API}/session/vendor/${encodeURIComponent(email)}/decision/`,
      { headers: { "x-api-key": API_KEY } }
    );
    res.json(response.data);
  } catch (err) {
    console.error("\u274C KYC status check error:", err.response?.data || err.message);
    res.status(500).json({ error: "Failed to get KYC status" });
  }
});
router.post("/send-kyc-link", async (req, res) => {
  try {
    const { name, email } = req.body;
    if (!name || !email) {
      return res.status(400).json({ success: false, error: "Missing fields." });
    }
    const response = await import_axios.default.post(
      `${DIDIT_API}/session/`,
      {
        workflow_id: WORKFLOW_ID,
        vendor_data: email,
        callback: CALLBACK_URL,
        metadata: { name, type: "significant_individual" }
      },
      {
        headers: {
          "x-api-key": API_KEY,
          "Content-Type": "application/json"
        }
      }
    );
    res.json({ success: true, url: response.data?.url });
  } catch (err) {
    console.error("\u274C Error creating KYC link:", err.response?.data || err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});
app.use("/.netlify/functions/server/api", router);
app.use("/api", router);
var handler = (0, import_serverless_http.default)(app);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
